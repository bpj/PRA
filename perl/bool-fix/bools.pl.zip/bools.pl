#!/usr/bin/env perl

use 5.014;
# use utf8;
use utf8::all;
use strict;
use warnings;
use warnings FATAL => 'utf8';
use autodie;

# use open qw[ :utf8 :std ];

use YAML::PP;
use Data::Rmap qw[rmap_array rmap_hash];
use Scalar::Util qw[blessed];

my $ypp = YAML::PP->new(
  schema => ['JSON'],
  boolean => 'JSON::PP',
);

my $data = $ypp->load_file('bools.yaml');

sub clone_bool {
  my($v) = @_;
  # return $v;
  my $class = blessed($v) || return $v;
  $class->isa('JSON::PP::Boolean') || return $v;
  my $copy = $$v;
  return bless \$copy => $class;
}

rmap_hash {
  my $class = blessed $_;
  my $c = +{ map {; clone_bool $_ } %$_ };
  bless $c => $class if $class;
  $_ = $c;
} $data;

rmap_array {
  my $class = blessed $_;
  my $c = [ map {; clone_bool $_ } @$_ ];
  bless $c => $class if $class;
  $_ = $c;
} $data;




$ypp->dump_file('bools1.yaml', $data);



